#!/usr/bin/env bash

apt install -y python3 build-essential
